# Product Overview — DocIntel AI Enterprise

## What it is
DocIntel AI Enterprise is a self-hostable document-intelligence and retrieval-augmented generation (RAG) application. Users upload supported business documents, ask questions in natural language, and receive answers intended to be grounded in retrieved source passages, with citations/evidence for review.

## Problem addressed
Teams often need to search policies, procedures, reports, and other document-heavy material. Generic chat tools may answer fluently without making it easy to inspect the source. DocIntel is designed around document retrieval, evidence visibility, and a clear response when the available documents do not support an answer.

## Core capabilities represented in the project documentation
- Email/password authentication and email verification
- Role-based access control and tenant-scoped access checks
- Multi-format document ingestion (including PDF, Word, Excel, PowerPoint, CSV, Markdown, text, RTF, and legacy Office formats, subject to documented limitations)
- Local embeddings and Chroma-based vector retrieval
- Local LLM answering through Ollama
- Multi-session chat history
- Citation/evidence viewing
- Tenant-scoped audit logging
- Evaluation harness for retrieval and answer-quality checks
- Docker Compose deployment materials

## Intended users
Document-heavy teams, consultancies, software vendors, and organizations exploring private or self-hosted document Q&A. Suitability for a particular regulated or enterprise production environment requires buyer-led security, legal, infrastructure, and performance review.

## Commercial stage
Pre-revenue technology asset. This preview does not claim paying customers, production traffic, independent security certification, or a guaranteed accuracy level.
