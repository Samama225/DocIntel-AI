# Security, Limitations, and Diligence Notes

## Security overview
Project materials describe authentication, email verification, role-based authorization, tenant-scoped access checks, and tenant-scoped audit logging. These are implementation claims from the supplied project documentation, not an independent security certification. A buyer should review code, threat model, dependency vulnerabilities, secrets management, HTTPS/reverse-proxy configuration, backup/restore, tenant isolation, and logging before production use.

## Known limitations to disclose
- OCR is disabled by default because accuracy requires additional validation. Scanned/image-only pages may be skipped or fail clearly rather than being reliably indexed.
- Complex Word documents containing embedded objects, SmartArt, WordArt, or other uncommon layouts may not extract fully.
- Retrieval and answer quality vary with document quality, chunking, embedding model, LLM, prompts, and configuration. A buyer-specific evaluation set is needed.
- Reference deployment uses local/single-node storage. Production scale, high availability, external object storage, and multi-node deployment are not implied.
- Email verification requires SMTP configuration.
- PyMuPDF is dual-licensed under AGPL/commercial terms. Resolve licensing for the intended distribution/hosting model with qualified legal advice before closed-source commercial use.

## Suggested diligence checks
1. Install and run the exact delivered code in a clean environment.
2. Run the automated tests and record failures, if any.
3. Validate document formats and evidence links using buyer-owned sample documents.
4. Test tenant separation with multiple accounts and adversarial requests.
5. Run a retrieval/answer evaluation using the buyer's expected questions and ground-truth passages.
6. Review third-party licenses, secrets, data retention, backup/restore, and deployment security.
