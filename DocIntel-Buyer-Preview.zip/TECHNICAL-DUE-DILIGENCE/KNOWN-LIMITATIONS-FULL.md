# Known Limitations

Disclosed proactively so a buyer's technical diligence confirms what's
already stated here, rather than discovering it independently. Every
item below is either a deliberate scope decision or a verified gap —
none of it is a hidden defect.

## Windows installation requires exact dependency versions

`chromadb` and `chroma-hnswlib` are pinned to exact versions
(`chromadb==0.5.4`, `chroma-hnswlib==0.7.5`) rather than a range. This
was found through real end-user installation on Windows + Python 3.12:
newer `chromadb` releases depend on a `chroma-hnswlib` version that PyPI
does not publish a Windows wheel for on Python 3.12, which causes
installation to fail with a C++ compiler error on any machine without
Microsoft's Build Tools installed. The pinned combination is verified
(via an actual successful install and working end-to-end document
upload) to install cleanly on Windows + Python 3.12 with no compiler
required. If this pin is ever changed, re-verify wheel availability for
the new `chroma-hnswlib` version on Windows before assuming it will
install cleanly.

## Word document extraction covers common layouts, not every possible one

`.docx` extraction reads body paragraphs, tables, headers/footers, and
text boxes (fixed after a real upload failure on a CV template that put
its content in a text box — see `CHANGELOG.md`). It does not yet extract
text from embedded objects (e.g. an embedded Excel sheet or PDF),
SmartArt diagrams, or WordArt. If a document's content lives in one of
those, it may still extract as unexpectedly sparse or empty.

## OCR is disabled by default

Early testing found the fused EasyOCR/PaddleOCR/Tesseract pipeline
wasn't accurate enough for production use (a real test run misread a
reference number). Rather than ship unreliable output, OCR is switched
off (`OCR_ENABLED=false`), and:
- A page with no extractable native text (a scanned page, an image-only
  page) is skipped with a clear, visible warning — it does not silently
  disappear, and it does not take down the rest of the document.
- A document that is *entirely* scanned/image-based fails clearly with
  an explanatory message, rather than producing an empty, useless index.
- The OCR code and dependencies are still present and can be re-enabled
  (`OCR_ENABLED=true` + install the commented-out packages in
  `requirements.txt`), but accuracy should be re-validated before
  relying on it in production.

## Automated tests use stubs; real-model validation was performed separately

Automated tests stub the heaviest dependencies (`sentence-transformers`,
`chromadb`, `ollama`) to keep the test suite fast and portable — see
`02-Documentation/TESTING.md`. This means:
- Parsing, chunking, authentication, authorization, and API behavior are
  verified for real.
- Embedding, retrieval, and local LLM behavior were also validated with the actual Ollama/RAG stack during final release preparation, including focused and multi-document queries.
- The automated pytest suite still stubs the heaviest dependencies for speed and portability; therefore the automated suite should not be interpreted as a production-scale performance benchmark.
- Answer quality remains dependent on the selected local model, embedding configuration, corpus, and deployment resources.

## Docker deployment validation

The Docker configuration was reviewed and an actual Docker/Compose deployment was successfully exercised during final validation. This confirms the deployment path for the tested environment; it does not constitute a full production infrastructure, HA, load, or security certification.

## Single-node architecture

- SQLite, local file storage, and a local Chroma index all live on one
  host. This is appropriate for a single-tenant pilot or a moderate
  number of tenants, but:
  - `ProgressService` (upload progress tracking) is an in-memory,
    per-process store — it is not safe to run multiple API workers or
    replicas without moving it to Redis or a database first.
  - There's no built-in horizontal scaling path for the vector store or
    file storage as-is.

## Email verification requires SMTP configuration

Registration will not fully work in a production deployment
(`ENVIRONMENT=production`) without real SMTP credentials — see
`03-Deployment/Environment-Template/README.md`. This is a required setup
step, not a bug.

## Licensing: PyMuPDF

`PyMuPDF`/`fitz` (used for PDF text extraction) is AGPL-3.0/commercial
dual-licensed. See `07-Licensing-IP/Third-Party-Dependencies.md` — this
needs a resolution (commercial license, or replacing the dependency)
before or shortly after acquisition, depending on the buyer's own
distribution model.

## Not built

- SSO / MFA / SCIM provisioning
- Malware/antivirus scanning on uploads
- Centralized log aggregation (SIEM)
- Formal compliance certification (SOC 2, ISO 27001, HIPAA BAA, etc.)
- Independent penetration testing
- Load testing beyond a lightweight probe script

None of these are unusual gaps for a product at this stage — they're
listed so a buyer can plan for them rather than assume they exist.
