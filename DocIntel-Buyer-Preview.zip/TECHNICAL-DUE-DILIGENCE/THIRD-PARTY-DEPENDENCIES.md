# Third-Party Dependencies & Licensing

**This document contains the single most important thing to review
before closing this deal. Read the flagged item first.**

## ⚠️ Requires a decision before/at close: PyMuPDF

`PyMuPDF` (imported as `fitz`) is used for PDF text extraction
(`app/parsers/pdf_parser.py`). It is dual-licensed:

- **GNU AGPL v3** (free), which requires that any product using it —
  including a hosted/SaaS product that customers only access over a
  network, even without distributing the code itself — be made fully
  open-source under an AGPL-compatible license.
- **Commercial license from Artifex Software** (the maker of the
  underlying MuPDF engine), for anyone who cannot or does not want to
  open-source their product.

**In plain terms:** running this product as closed-source software —
which is presumably the buyer's intent — technically requires a
commercial license from Artifex. This was not resolved as part of this
build. Options, in rough order of effort:

1. **Buy a commercial PyMuPDF/MuPDF license from Artifex.** Pricing is
   quoted per-project (contact Artifex sales directly).
2. **Replace PyMuPDF with a permissively-licensed alternative**
   (e.g. `pypdfium2`, which wraps Google's PDFium under a
   BSD/Apache-style license) — this is an engineering task, scoped to
   `app/parsers/pdf_parser.py` and the OCR page-rendering calls in
   `app/ai/ocr_service.py`/`tesseract_service.py` that also use `fitz`.
3. **Open-source the product**, if that's compatible with the buyer's
   business model (unlikely for most acquirers of this package).

**This is a legal question, not just a technical one — consult an IP
attorney before deciding**, especially before high-volume commercial
use. Whether this is resolved by the seller before close, or by the
buyer after, should be an explicit term of the sale agreement, not left
implicit.

## Everything else: permissively licensed

The dependencies below are believed to carry the licenses shown, based
on their published packaging metadata as of this package's preparation.
**Run an automated license scan** (e.g. `pip-licenses` for Python,
`license-checker` for npm) against the exact dependency versions
resolved at your install time before relying on this list for legal
purposes — license terms and transitive dependencies can change between
versions.

### Backend (Python)

| Package | License (as published) |
|---|---|
| FastAPI | MIT |
| Uvicorn | BSD-3-Clause |
| Pydantic / pydantic-settings | MIT |
| python-multipart | Apache-2.0 |
| email-validator | MIT (via CC0-licensed underlying data in some versions — verify) |
| Chromadb | Apache-2.0 |
| sentence-transformers | Apache-2.0 |
| python-docx | MIT |
| openpyxl | MIT |
| python-pptx | MIT |
| Ollama (Python client) | MIT |
| pytest | MIT |
| langchain-text-splitters | MIT |
| LibreOffice (system dependency, used via subprocess for legacy formats) | MPL-2.0 |
| EasyOCR, PaddleOCR, pytesseract, opencv-python-headless, numpy (optional — off by default) | Apache-2.0 / BSD-3-Clause (Tesseract engine itself is Apache-2.0) |

### Frontend (JavaScript)

| Package | License (as published) |
|---|---|
| React / React DOM | MIT |
| Vite | MIT |
| @vitejs/plugin-react | MIT |

All of the above are permissive licenses that do not require
open-sourcing this product or paying royalties — they typically only
require retaining the license/copyright notice, which `pip`/`npm`
already preserve in each package's own distribution.

## Recommended pre-close action

1. Run `pip-licenses` and `npm ls --all` (or `license-checker`) against
   `01-Product/Backend/requirements.txt` and
   `01-Product/Frontend/package.json` to get a machine-verified,
   version-pinned license report.
2. Resolve the PyMuPDF question explicitly in the sale agreement —
   either seller resolves it pre-close, or the price/terms reflect that
   the buyer takes it on.
