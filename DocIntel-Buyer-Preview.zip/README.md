# DocIntel AI Enterprise — Buyer Preview

This is a **buyer-facing preview package**, not the complete source-code delivery. It contains product and technical overview material, a fictional demo document, suggested demo questions, and disclosed technical/licensing considerations.

## What is included
- Product overview and capability summary
- High-level architecture and technology stack
- Demo guide and fictional sample HR policy
- Security overview, deployment overview, known limitations
- Acquisition handover checklist
- Product visual asset from the project (not a live application screenshot)

## Important status disclosures
- The project is pre-revenue; no paying customers or production traffic history are represented here.
- OCR is disabled by default because its accuracy needs further validation.
- PyMuPDF has AGPL/commercial licensing implications that must be resolved for a closed-source commercial deployment. See `TECHNICAL-DUE-DILIGENCE/SECURITY-AND-LIMITATIONS.md` and `ACQUISITION/ASSETS-INCLUDED.md`.
- This preview does not include application source code, credentials, user data, or deployment secrets. Full source can be discussed privately with qualified buyers, subject to the marketplace's rules and appropriate transaction safeguards.

## Before uploading
Check Zero to Hundred's current listing rules. If the marketplace explicitly requires the actual source-code ZIP, do not present this preview as the complete codebase. Ask support whether a documentation/demo preview is acceptable for public listing and source can be shared privately during diligence.

## Demo video
Use the separate Video Walkthrough field for the demo video rather than bundling a large video in this ZIP.
