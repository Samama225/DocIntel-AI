# Deployment Overview

The project is designed around a React/Vite frontend, FastAPI backend, persistent local data/vector storage, and an Ollama runtime for local LLM inference.

A live deployment normally needs separately configured components:
1. Frontend hosting (static SPA hosting is suitable for the built frontend).
2. Backend hosting capable of running the Python API.
3. Persistent storage for database, uploaded files, metadata, and vector index.
4. An Ollama/local-model host with sufficient CPU/RAM (or a separately engineered model provider integration).
5. Environment variables, CORS, HTTPS/reverse proxy, SMTP if email verification is enabled, and backup/restore procedures.

**Important:** Vercel can host the frontend, but it is not a drop-in host for the full local Ollama + persistent FastAPI stack. Treat frontend and backend/model hosting as separate deployment decisions. Validate costs, storage persistence, resource limits, and security on the chosen host.
