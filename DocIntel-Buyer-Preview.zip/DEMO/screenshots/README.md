# Screenshots

No application screenshots are included in this preview because the package did not contain verified screenshots of the running application. Add up to five genuine screenshots captured from the actual running product before using this folder for a marketplace listing. Do not present mockups or the included hero asset as a screenshot of a working deployment.
