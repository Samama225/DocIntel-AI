# Demo Questions

Use these with the included fictional HR policy in `DEMO/demo_policy.txt`.

1. **What is the probationary period?** — Expected: 3 months.
2. **How many days of annual leave are provided?** — Expected: 24 days per year.
3. **Does the document mention nuclear reactor maintenance?** — Expected: the system should say the supplied document does not provide that information, rather than invent an answer.
4. **Can employees work remotely?** — Expected: up to 3 days per week, according to the sample policy.
5. **How much notice is needed before resigning?** — Expected: 30 days.
6. **How often are salary reviews conducted?** — Expected: annually.
7. **What is the difference between the notice period and probationary period?** — Expected: compare the two separate policy provisions and cite the supporting source passages.

Demo suggestion: begin with question 3 to show the importance of not inventing unsupported facts, then ask a supported question and inspect its source evidence. These are demo expectations, not a production benchmark.
