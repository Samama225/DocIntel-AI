# High-Level Architecture

```text
Browser (React/Vite)
        |
        v
FastAPI API
  |-- Authentication / authorization / tenant checks
  |-- Upload and document endpoints
  |-- Chat and session endpoints
  |-- Citation/evidence endpoints
  |-- Evaluation endpoints
        |
        v
Document processing
  Parse -> Chunk -> Embed -> Store in Chroma
        |                     |
        v                     v
Local files/metadata       Vector retrieval
                              |
                              v
                         Ollama local LLM
                              |
                              v
                     Answer + source evidence

Supporting components: SQLite, audit logging, optional SMTP verification,
optional OCR (disabled by default in the supplied project configuration).
```

## Deployment shape
The reference configuration is designed for a single-node environment with persistent local storage and local model serving. Public hosting requires a separately hosted API, persistent storage, and Ollama/model runtime; deploying only the frontend to Vercel does not provide the backend or local inference runtime.
