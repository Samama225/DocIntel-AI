# Feature Summary

| Area | Summary | Notes |
|---|---|---|
| Document ingestion | Parses several common office and text formats | Complex embedded objects/layouts may not extract completely |
| RAG Q&A | Retrieves document passages and uses an LLM to draft answers | Output quality depends on source quality, retrieval configuration, and model choice |
| Evidence | Citation/evidence workflow for inspecting source material | Buyer should verify the end-to-end workflow in their target environment |
| Identity and access | Authentication, role-based authorization, tenant-scoped checks | Buyer should perform an independent security review before production |
| History | Multi-session chat history | Persistent storage/deployment setup must be reviewed for the buyer's scale |
| Evaluation | Includes a project evaluation harness and automated tests | Test results are not a substitute for a buyer-specific benchmark |
| Local inference | Ollama + local embedding model path | Requires compatible host resources and model downloads; not a Vercel-only deployment |
| Containers | Docker/Docker Compose configuration | Deployment must be validated for the buyer's target host |

For exact verified status, inspect the full technical documentation and tests during private diligence.
