# Preview Contents and Acquisition Handover

## Included in this public preview ZIP
- Buyer-facing product overview, feature summary, architecture, and technology stack
- Fictional sample HR policy and demo questions
- Security/limitations and deployment notes
- Project hero visual asset (illustrative asset, not a screenshot of a live deployment)

## Not included in this preview ZIP
- Full application source code or repository history
- Production credentials, API keys, `.env` files, deployment tokens, or private certificates
- Real user/customer data or private business documents
- Any claim of revenue, paying customers, production traffic, independent certification, or guaranteed accuracy

## Private handover can be scoped separately
Subject to marketplace rules and a mutually agreed transaction, a complete handover may cover source code, tests, documentation, deployment configuration, demo assets, and a defined knowledge-transfer window. Final scope, IP assignment, dependency licensing, and any support obligation should be written into the sale agreement.

## Critical licensing item
PyMuPDF has AGPL/commercial licensing implications. A buyer intending to operate a closed-source commercial product must resolve this before production use, either through a suitable commercial license or a reviewed replacement. This preview does not represent that issue as resolved.
