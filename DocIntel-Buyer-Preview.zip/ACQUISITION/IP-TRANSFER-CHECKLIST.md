# IP Transfer Checklist

Use this at closing to confirm everything has actually been handed over
— not just promised. Check off each item as it's completed, by both
parties.

## Legal

- [ ] Asset Purchase Agreement (APA) signed by both parties, including
      an explicit IP assignment clause covering all source code,
      documentation, and this package's contents
- [ ] NDA executed (if not already in place from due diligence)
- [ ] Payment received and confirmed in escrow before any irreversible
      transfer step below
- [ ] Non-compete/non-solicit terms agreed, if applicable (seller
      agreeing not to rebuild and resell an identical product for a
      defined period)
- [ ] Licensing decision on PyMuPDF documented in the agreement — see
      `Third-Party-Dependencies.md` (resolved pre-close, or explicitly
      assigned to the buyer as a post-close task)

## Code & repository

- [ ] Source code repository ownership transferred (e.g. GitHub
      organization/repo transfer, or a fresh push to a buyer-owned
      repository with full commit history preserved)
- [ ] Confirm the buyer can independently clone/access the repository
      after transfer (test this before considering the step done)
- [ ] All 43 tests re-run and passing in the buyer's own environment
      post-transfer (see `01-Product/Source-Code/README.md`)

## Secrets & credentials

- [ ] **Rotate every secret before or immediately at transfer**:
      `AUTH_SECRET`, SMTP credentials, any API keys — never hand over
      credentials that were used during the seller's own testing/demo
      period
- [ ] Confirm no real user data, API keys, or credentials are present in
      the codebase, test fixtures, or `.env` files being transferred
      (only `.env.example` with placeholder values should be included)
- [ ] Domain name transferred, if one is included in the sale (not
      assumed by default — confirm explicitly in the APA)

## Documentation & knowledge transfer

- [ ] This entire package handed over as-is
- [ ] Handover/training call(s) completed per the agreed scope (see
      `06-Commercial/Pricing.md` for what's included by default vs.
      negotiable)
- [ ] Seller available for the agreed post-close support window (define
      the exact duration and scope in the APA — "reasonable support" is
      not a defined term and leads to disputes)

## Final confirmation

- [ ] Buyer confirms receipt of all items above in writing
- [ ] Seller confirms no retained copies of the product will be
      operated, sold, or further developed outside the terms of the
      non-compete clause (if one exists)
