# Technology Stack

- **Frontend:** React 19, Vite, JavaScript/JSX, CSS
- **API:** Python, FastAPI, Uvicorn, Pydantic
- **Auth/data:** SQLite for selected account/auth data; local filesystem for files/metadata
- **Vector retrieval:** Chroma
- **Embeddings:** sentence-transformers/local embedding model
- **LLM serving:** Ollama (local inference path)
- **Document processing:** PyMuPDF and Python office-format parsers; LibreOffice for legacy Office conversion
- **Evaluation/testing:** pytest and project evaluation scripts
- **Deployment:** Docker and Docker Compose

The project is primarily a single-node/self-hosted architecture. A buyer planning multi-node scaling, managed storage, or public SaaS should scope and validate those changes separately.
